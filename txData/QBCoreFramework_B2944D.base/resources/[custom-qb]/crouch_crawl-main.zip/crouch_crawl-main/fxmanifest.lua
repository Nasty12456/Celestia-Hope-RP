fx_version 'cerulean'
game 'gta5'
lua54 'yes'

authors 'Mads'
description 'Crouch & Crawl'
version '1.0.1'

client_scripts {
    'config.lua',
    'walkstyles.lua',
    'client.lua'
}
